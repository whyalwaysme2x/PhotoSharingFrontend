const api = "http://localhost:8081"

const sysVar = {
    api: api,
}

export default sysVar;